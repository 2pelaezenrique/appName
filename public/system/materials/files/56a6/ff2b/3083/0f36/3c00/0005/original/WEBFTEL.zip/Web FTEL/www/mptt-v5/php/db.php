<?php include_once("lib.php"); include_once("/var/credentials/mptt.inc");
// WARNING. Do not add any charater, \n,\t,\s .... to text within tags. It est: "<tag>kkk</tag>" is different from "<tag>\n\tkkk\n</tag>"
$db="mpttdb"; checkStringParameter($db,50);
$tonos_table="tonos"; checkStringParameter($tonos_table,50);
$tuiteros_table="tuiteros"; checkStringParameter($tuiteros_table,50);
$perfil_table="perfil"; checkStringParameter($perfil_table,50);
$host="localhost"; $usr="root"; 
$sql_tuiteros=" SELECT * FROM  $tuiteros_table  "; 
$sql_tono=" SELECT fichero_audio FROM  $tonos_table WHERE id_tono="; 
$sql_perfiles=" SELECT * FROM  $perfil_table "; 
$sql_perfil=" SELECT * FROM  $perfil_table WHERE id_perfil="; 
$sql_tuiteros_del_perfil=" SELECT nombre_tuitero FROM  $tuiteros_table WHERE id_perfil="; 
$cid= mysql_connect($host,$usr,$pwd) or die("$title db.php - mySQL connect error: " . mysql_error());
$r= mysql_select_db($db) or die("$title db.php - mySQL select error: " . mysql_error());
$r= mysql_query("$sql_tuiteros") or die("$title db.php - mySQL tuiteros query error: " . mysql_error(). ", sql = $sql_tuiteros"); 
$d='<?xml version="1.0" encoding="UTF-8" ?>' . "\n" . "<mipitatuiterDB>\n\t<toneoftweetertable>";
while ($l = mysql_fetch_array($r)) {
    $tweeter=$l["id_tuitero"];
    $rr= mysql_query("$sql_tono'".$l["id_tono"]."' ") or die("$title db.php - mySQL tonos query error:  sql = $sql_tono, error= ". mysql_error()); 
    $ll = mysql_fetch_array($rr); $tono= $ll["fichero_audio"];
    $d .= "\n\t\t<association>\n\t\t\t<tone>".$tono."</tone>\n\t\t\t<twitter>".$tweeter."</twitter></association>"; }
$d .="</toneoftweetertable>";
$d .="\n\t<perfilestable>";
$r= mysql_query("$sql_perfiles") or die("$title db.php - mySQL perfiles query error: " . mysql_error(). ", sql = $sql_perfiles"); 
while ($l = mysql_fetch_array($r)) {
    $perfil=$l["id_perfil"];
    $rr= mysql_query("$sql_perfil'".$perfil."' ") or die("$title db.php - mySQL perfiles query error:  sql = $sql_perfil, error= ". mysql_error()); 
    $ll = mysql_fetch_array($rr); $pnombre= $ll["nombre"]; $pinteres=$ll["interes"]; $pactividad=$ll["actividad"];$ptema=$ll["tema"];$pmin_popularidad=$ll["min_popularidad"];
    $d .= "\n\t\t<perfil>\n\t\t\t<nombre>".$pnombre."</nombre>\n\t\t\t<interes>".$pinteres."</interes>\n\t\t\t<actividad>".$pactividad."</actividad>\n\t\t\t<tema>".$ptema."</tema>\n\t\t\t<min_popularidad>".$pmin_popularidad."</min_popularidad>";
    $rr= mysql_query("$sql_tuiteros_del_perfil'".$perfil."' ") or die("$title db.php - mySQL tutiteros del perfil query error:  sql = $sql_tuiteros_del_perfil, error= ". mysql_error());
    while ($ll = mysql_fetch_array($rr)) {
      $tuitero_del_perfil=$ll["nombre_tuitero"]; $d.="\n\t\t\t<tuitero>".$tuitero_del_perfil."</tuitero>"; }
    $d.="</perfil>"; }
$d .= "</perfilestable>\n</mipitatuiterDB>\n";
mysql_close($cid);
header('Content-Type: text/xml');
print $d;
?>
