<?php
//  ---- Messages title  --------
$title="FTEL - mpttv5 -";
//  ---- Error functions --------
function customError($errno, $errstr) { echo "<b>mptt error:</b> [$errno] $errstr" . "<br />"; }
set_error_handler("customError");
//  to test execute following sentence
//echo($test);
//
//  ---- Trace functions --------
$traceOn = false;
function Trace($t) { global $traceOn; if (!$traceOn) return true; echo "<br />TRACE: " . print_r($t,true)."."; }
//  to test uncomment the following line
//Trace("hola");
//
//  ---- Check Parameters functions --------
function checkStringParameter($s,$lmax){ 
   $l= strlen($s); 
   if (($l > $lmax) || ($l < 0)) {
       Trace("checkStringParameter: Max Length= ".$lmax.", lenght= ".$l.", string= ".$s); die();}
}
function checkNummericParameter($n,$nmax){
   if (($n > $nmax) || ($n < 0)) {
      Trace("checkNummericParameter: Max Value= ".$nmax.", value= ".$n."."); die();}
}
?>
