//---------------------------------------------------------------------------
//   My Ringtoned Tweets Timeline (miPitatuiter) javascript library
//
// "ConfData" object holds system parameters.
//
function error(x) {var s = "index.js ERROR: " + x; alert(s); throw(s);}
function warning(x) {var s = "index.js WARNING: " + x; if (typeof console != undefined) console.log(s); throw(s);}
var pollingPeriod = 30000; /*msec*/ var polledTweets = 10;
var nextTweetID = []; var charset=""; 
var tweets = []; function tweet(id_str,d,a,i,n,n2,t){this.id_str=id_str; this.date=d; this.audio=a; this.image=i; this.name=n; this.name2=n2; this.text=t}; //  : Keeps <td>X</td> content
function twitterUrl(n,si){return("php/tweets.php?user="+n+"&count="+polledTweets +"&since_id=" +si);}
function dbUrl(db,tab){ return ("php/db.php");}
function getTwitterTime(s){var v=s.split(' '); return new Date(Date.parse(v[1]+" "+v[2]+", "+v[5]+" "+v[3]+" UTC")).getTime();}
var confData = {
   tweetsDivName: "myTweets", perfilesDivName: "myPerfiles", tonesRelPath: "contenidos", dbName: "mpttdbv5", table: "",
   setConfData: function(xObj){ if (typeof console != 'undefined') console.log("setConfData: xObj= "+xObj); // xml object
                        if (xObj && $(xObj).find("mrttconfiguration") && ($(xObj).find("mrttconfiguration").text() != "")) { 
                           if (typeof console != 'undefined') console.log("setConfData: mrttconfiguration= "+$(xObj).find("mrttconfiguration"));
                           this.dbName = $(xObj).find("mrttconfiguration").find("DBname").text(); this.table = $(xObj).find("mrttconfiguration").find("toneOfTweeterTableName").text();}
                           this.teetsDivName = $(xObj).find("mrttconfiguration").find("tweetsDIVname").text(); this.perfilesDivName = $(xObj).find("mrttconfiguration").find("perfilesDIVname").text();
                           this.tonesRelPath = $(xObj).find("mrttconfiguration").find("tonesRelativePath").text();
                }
}
var dbData = {
   twittersData: [],
   setTweetersData: function(xObj){ if (typeof console != 'undefined') console.log("setTweetersData: xObj= "+xObj); 
                        var ltd=[]; 
                        $(xObj).find("association").each(function(i){ ltd[i] = {}; if (typeof console != 'undefined') console.log("setTweetersData->association= "+i);
                           ltd[i].name= $(this).find("twitter").text(); ltd[i].audio= $(this).find("tone").text(); }); 
                        this.twittersData = ltd; },
   twittersNo: function(){return(this.twittersData.length);},
   twitterIdx: function(n){for (var i=0; i<this.twittersNo(); i++) if (this.twittersData[i].name == n) return(i); error("db Data-twitterIdx: Name: "+ n +", not found"); },  
   audioOfTwitter: function(n){for (var i=0;i<this.twittersNo();i++) if (this.twittersData[i].name == n) return(this.twittersData[i].audio); error("db Data-audio: Name: "+ n +", not found");},
   twitterName: function(i){if ((i>=0) && (i<this.twittersNo())) return(this.twittersData[i].name); error("db Data-name: twitterIdx: "+ i +", out of range"); },
   perfilesData: [],
   setPerfilesData: function(xObj){ if (typeof console != 'undefined') {console.log("setPerfilesData: xObj= "); console.log(xObj); }
                        var lpd=[]; 
                        $(xObj).find("perfil").each(function(i){ lpd[i] = {}; 
                           if (typeof console != 'undefined') { console.log("setPerfilesData->perfil= "+i+", this= "); console.log(this);}
                           lpd[i].nombre= $(this).find("nombre").text(); lpd[i].interes= $(this).find("interes").text(); lpd[i].actividad= $(this).find("actividad").text();
                           lpd[i].tema= $(this).find("tema").text(); lpd[i].min_popularidad= $(this).find("min_popularidad").text();
                           lpd[i].nombre= $(this).find("nombre").text(); 
                           lpd[i].tuiteros={};
                           $(this).find("tuitero").each(function(j){
                                if (typeof console != 'undefined') { console.log("setPerfilesData->perfil+tuitero= "+i+"."+j+", this= "); console.log(this);}
                                lpd[i].tuiteros[j]=$(this).text();
                           });
                           if (typeof console != 'undefined') { console.log("setPerfilesData: i, lpd[i]= "+i+", "); console.log(lpd[i]); }
                        }); 
                        this.perfilesData = lpd; },
   perfilesNo: function(){return(this.perfilesData.length);},

}
function hyperlinkTweetText(t){ if (typeof console != 'undefined') console.log("hyperlinkTweetText- t: "+t);
   var arrobaLink =  "$1<a href='https://twitter.com/$2'>@$2</a>";
   var hashtagLink = "$1<a href='https://twitter.com/#!/search?q=%23$2'>#$2</a>";
   var httpLink =    "$1<a href='$2'>$2</a>";
   var r1 =  t.replace(/(^|\s|\.|\,)(http:\/\/[A-Za-z0-9\/\?\&\-\_\.]+)/g,httpLink); 
   var r2 = r1.replace(/(^|\s|\.|\,)#(\w+)/g,hashtagLink);
   var r  = r2.replace(/(^|\s|\.|\,)@(\w+)/g,arrobaLink);
   if (typeof console != 'undefined') console.log("hyperlinkTweetText: "+t+" -> "+r);
   return r;
}
function showTweetEntries(){ var html=""; if (typeof console != 'undefined') console.log("showTweetEntries - tweets no: "+tweets.length);
   if (!tweets) error("Write Tweets-undefined tweets"); if (tweets.length == 0) return ;
   for (var k in tweets) { 
       var id_str=tweets[k].id_str; var d=tweets[k].date; var a=tweets[k].audio; var i=tweets[k].image; var n=tweets[k].name; var n2=tweets[k].name2; var t=tweets[k].text;
       html += "<tr><td rowspan='3' class='image'><a href=\"https://twitter.com/"+n+"\">"+i+"</a>"+a+"</td>";
       html += "<td class='name'><a href=\"https://twitter.com/"+n+"\">"+n2+"</a></td>";
       html += "<td rowspan='2' class='date'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class='actions' href=\"https://twitter.com/"+n+"status"+id_str+"\">"+d+"</a></td></tr>";
       html += "<tr><td class='username'><a href=\"https://twitter.com/"+n+"\">@"+n+"</a></td></tr>";
       html += "<tr><td colspan='2' class='text'>&nbsp;&nbsp;&nbsp;&nbsp;"+t+"</td></tr>";
       html += "<tr><td>&nbsp;</td><td colspan='2'>&nbsp;&nbsp;&nbsp;<a class='actions' href=\"https://twitter.com/intent/tweet?in_reply_to="+id_str+"\"><img src=\"https://si0.twimg.com/images/dev/cms/intents/icons/reply.png\">Responder</a>&nbsp;<a class='actions' href=\"https://twitter.com/intent/retweet?tweet_id="+id_str+"\"><img src=\"https://si0.twimg.com/images/dev/cms/intents/icons/retweet.png\">Retwittear</a>&nbsp;<a class='actions' href=\"https://twitter.com/intent/favorite?tweet_id="+id_str+"\"><img src=\"https://si0.twimg.com/images/dev/cms/intents/icons/favorite.png\">Favorito</a> </td></tr>";
       html += "<tr><td colspan='3'>&nbsp;</td></tr>";
   }
   $("#myTweetsList").prepend(html);
}
function showPerfilEntries(){ var html=""; if (typeof console != 'undefined') { console.log("showPerfilEntries - perfiles no, perfiles: "+dbData.perfilesNo()+", "); console.log(dbData.perfilesData);}
   if (!dbData.perfilesData) error("Write Perfiles-undefined dbData.perfilesData"); if (dbData.perfilesNo() == 0) return ;
   for (var k in dbData.perfilesData) { if (typeof console != 'undefined') { console.log("showPerfilEntries - k, perfil k= "+k+", "); console.log(dbData.perfilesData[k]);}
       var n=dbData.perfilesData[k].nombre; var i=dbData.perfilesData[k].interes; var a=dbData.perfilesData[k].actividad; var t=dbData.perfilesData[k].tema; 
       var mp=dbData.perfilesData[k].min_popularidad; var tp=dbData.perfilesData[k].tuiteros; 
       html += "<tr><td colspan='2' class='nombre'>"+n+"</td></tr>";
       html += "<tr><td class='titulo'>Interes:</td><td class='interes'>"+i+"</td></tr>";
       html += "<tr><td class='titulo'>Actividad:</td><td class='actividad'>"+a+"</td></tr>";
       html += "<tr><td class='titulo'>Tema:</td><td class='tema'>"+t+"</td></tr>";
       html += "<tr><td class='titulo'>Pop.Mín.:</td><td class='popmin'>"+mp+"</td></tr>";
       html += "<tr><td class='titulo'>Tuiteros:</td><td class='tuiteros'>"; for (var l in tp){html += tp[l]+", ";} html += "</td></tr>";
   }
   if (typeof console != 'undefined') { console.log("showPerfilEntries - hatml= "); console.log(html);}
   $("#myPerfilesList").prepend(html);
}
function sortTweets(){ var done="false"; var t = []; if (typeof console != 'undefined') console.log("sortTweets- tweetsNo: "+tweets.length);
   if (!tweets) error("Sort Tweets-undefined tweets"); if ((tweets.length == 0)  || (tweets.length == 1)) return ;
   for (var i in tweets) t[i] = getTwitterTime(tweets[i].date);//new Date.parse(tweets[i].date).getTime(); 
   while (done!="true") { done="true"; 
       for (var i=0; i< (tweets.length-1); i++){
           //if (typeof console != 'undefined') console.log("sort tweets- length, i, date[i]:t[i], date[i+1]:t[i+1], done: "+tweets.length+", "+i+", "+tweets[i].date+":"+t[i]+", "+tweets[i+1].date+":"+t[i+1]+", "+done);
           if(t[i] < t[i+1]){done="false"; var x=tweets[i]; var y=t[i]; tweets[i]=tweets[i+1]; t[i]=t[i+1]; tweets[i+1]=x; t[i+1]=y;}}} 
} 

function mashUpTweets(txt){ 
    var id_str=""; var d=""; var a=""; var i=""; var n=""; var n2=""; var t=""; var tl=[]; //if (typeof console != 'undefined') console.log("mashUpTweets tweets: - Start " + tweets.length ); 
    //if (typeof console != undefined) console.log("mashUpTweets -----------------------------------------------------------");
    //if (typeof console != undefined) console.log("mashUpTweets txt: "+txt);
    obj = JSON.parse(txt);
    //if (typeof console != undefined) console.log("mashUpTweets: obj.length " + obj.length);
    if (obj.length > 0) {
        //if (typeof console != undefined) console.log("mashUpTweets ... entrando");
        n = obj[0].user.screen_name;
        n2 = obj[0].user.name;
	//if (typeof console != undefined) console.log("mashUpTweets n " + n);
        a= "<audio autoplay><source src='" + confData.tonesRelPath+"/" + dbData.audioOfTwitter(n) + "' type='audio/wav'>No hay soporte de audio.</audio>";
        i="<image src=" + obj[0].user.profile_image_url +" />"; 
	//if (typeof console != undefined) console.log("mashUpTweets i " + i);
        for (var k=0; k < obj.length; k++) {
           id_str=obj[k].id_str;
	   //if (typeof console != undefined) console.log("mashUpTweets id " + id_str+ "  id_str: "+obj[k].id_str);
           d=obj[k].created_at;
	   //if (typeof console != undefined) console.log("mashUpTweets created_at " + d);
           t=hyperlinkTweetText(obj[k].text); tweets[tweets.length]=new tweet(id_str,d,a,i,n,n2,t); a=""; }
        nextTweetID[dbData.twitterIdx(n)]= obj[0].id_str;
        //if (typeof console != undefined) console.log("mashUpTweets: n-->"+n+" id_str-->"+obj[0].id_str+" dbData.twitterIdx(n)-->"+dbData.twitterIdx(n));
    }
    //if (typeof console != 'undefined') console.log("mashUpTweets tweets - End: " + tweets.length); 
}
function getPeriodically(){ if (typeof console != 'undefined') console.log("getPeriodically - twittersNo: " + dbData.twittersNo());
    for (var tw= 0; tw < dbData.twittersNo(); tw++){
        var u= twitterUrl(dbData.twitterName(tw),(nextTweetID[tw]?nextTweetID[tw]:0)); if (typeof console != 'undefined') console.log("getPeriodically - tw "+tw+", url: "+u);
        // $.ajax({url: u, dataType: 'json', async: false, success: function(x){mashUpTweets(x);}, error: function(x,t,e){warning("Get Tweets Error - x: "+x+", t: "+t+", e: "+e); } }); }
        $.ajax({url: u, dataType: 'text', async: false, success: function(x){mashUpTweets(x);}, error: function(x,t,e){warning("Get Tweets Error - x: "+x+", t: "+t+", e: "+e); } }); }
    sortTweets(); showTweetEntries(); tweets= []; setTimeout(getPeriodically, pollingPeriod * dbData.twittersNo());
}
function getXmlDB(){ if (typeof console != 'undefined') console.log("getXmlDB - Start");
    $.ajax({url: dbUrl(), dataType: 'xml', async: false, success: function(x){dbData.setPerfilesData(x); dbData.setTweetersData(x);},
            error: function(x,t,e){error("Get Tweeters DB Error - x: "+x+", t: "+t+", e: "+e); } });
    if (typeof console != 'undefined') console.log("getXmlDB - End");
}
$(function(){ var html;
      html = "<center><table id='myTweetsList'></table></center>"; $("#"+confData.tweetsDivName).html(html); 
      html = "<center><table id='myPerfilesList'></table></center>"; $("#"+confData.perfilesDivName).html(html); 
      getXmlDB(); showPerfilEntries(); getPeriodically();
 }
);
