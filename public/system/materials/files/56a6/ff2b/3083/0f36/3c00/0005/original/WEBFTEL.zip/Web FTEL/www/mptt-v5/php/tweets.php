<?php include_once("lib.php"); include_once("twitteroauth.php"); include_once("/var/credentials/mptt.inc");

if (isset($_GET["public"])) $public="public"; else $public=""; checkStringParameter($public,10);
if (isset($_GET["user"])) $user=htmlspecialchars_decode(trim($_GET["user"])); else $user=""; checkStringParameter($user,50);
if (isset($_GET["count"])) $count=htmlspecialchars_decode(trim($_GET["count"])); else $count=0; checkNummericParameter($count,100);
if (isset($_GET["since_id"])) $since_id=htmlspecialchars_decode(trim($_GET["since_id"])); else $since_id=""; checkStringParameter($since_id,30);


if ($public != "") {$u="statuses/public_timeline.json?count=" . $count;}
elseif ($user != "") {$u="statuses/user_timeline/" . $user . ".json?count=" . $count;}
else die("$title - tweets.php - neither public not specific user timeline request");
if (($since_id != "") && ($since_id != "0")) {$u .= "&since_id=" . $since_id;}

$connection = new TwitterOAuth($cons_key, $cons_secret, NULL, NULL);

$content = $connection->get($u);

header('Content-Type: text/json');
print_r( $content);
?>
