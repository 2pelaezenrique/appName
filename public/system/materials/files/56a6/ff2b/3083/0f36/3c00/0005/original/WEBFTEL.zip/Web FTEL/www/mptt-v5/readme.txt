versión v5 - 11/12/14
-- Se cambia el formato de la página para que tenga una columna vertical donde puedan rellenar su nombre y apellidos y aparezcan los nuevos campos que se han añadido a la práctica de BBDD este curso.
-- Se intenta añadir un fichero de configuración basado en xml.
versión v4 - 3/8/13
-- Adaptación a las nuevas condiciones de uso de la API de twitter (autenticación y presentación).
versión v3 - 30/11/12
-- Adaptación a las nuevas URL de la API de twitter.

versión v2 - 2/1/12
-- Se añade comillas en la lecturas de la BD al obtener los tonos de un tuitero porque el identificador de tono puede incluir blancos.
-- Se aumenta el periodo de muestro de twitter a 5' = 60000 * 5
-- Se suprime el mensaje de error que presenta firefox cuando no recibe una contestación mala por parte de twitter.

versión v1 -
281211 - Se construye esta versión, con el nombre mptt, a partir de mrtt-v3 para:
-- Adecuarla a la Base de datos definida en la práctica 6 (BD) de 2011-2012
-- Eliminar los ficheros de configuración del portal mrtt.conf
-- Y del fichero de definición xml, mrttconf.xsd, del lenguaje con el que se describe mrtt.conf. 
versión v3 -  
071211 - console no existe si no está cargado el "debug" del navegador
versión v2 - 
26/11/11 - Trace no se puede usar en los php que se llaman vía ajax
31/8/11 - Incluye las funciones php "Trace" desarrolladas para el portal de administración de los servidores personales que tienen una variable lógica para habilitarlas.
